#!/bin/bash

cgdb ../riscv-softmmu/qemu-system-riscv -x startqemu
