#!/bin/bash

./qemu-system-riscv -kernel ../hacking/vmlinux/vmlinux -nographic
