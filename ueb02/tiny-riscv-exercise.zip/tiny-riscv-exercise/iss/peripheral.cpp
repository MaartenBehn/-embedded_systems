/*
 * peripheral.cpp
 *
 *  Created on: Oct 27, 2022
 *      Author: pp
 */


#include "peripheral.hpp"

uint32_t CharacterPrinter::load_data(const Address addr) {
    // TODO: Task 5
	return 0;
}

void CharacterPrinter::store_data(const Address addr, const uint32_t value) {
    // TODO
}
